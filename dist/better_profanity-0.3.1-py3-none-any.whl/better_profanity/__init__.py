name = 'better_profanity'
__version__ = '0.3.1'
